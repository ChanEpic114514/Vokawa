// Run: npm install --no-save playwright && node tests/preview.spec.cjs
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const path=require('node:path');
let backend;
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright' : 'playwright');
(async()=>{
 backend=spawn('python3',[path.join(__dirname,'../backend/server.py'),'--port','8876'],{env:{...process.env,VOKAWA_TOKEN:'test-only'}});
 await new Promise((resolve,reject)=>{backend.stdout.once('data',resolve);backend.once('error',reject);backend.once('exit',code=>reject(Error('Backend exited '+code)))});
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||undefined,args:["--no-sandbox"]});
 const page=await browser.newPage({viewport:{width:1100,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8876');
 let checks=0;
 for (const src of ['en','zh','yue'])for(const dst of ['en','zh','yue']){
  if(src===dst)continue;
  await page.selectOption('#src',src);await page.selectOption('#dst',dst);
  await page.locator('summary').click();await page.locator('[data-sample="0"]').click();await page.locator('#translate').click();
  await page.waitForSelector('.content .result');assert.ok((await page.locator('.content .result').first().innerText()).length);checks++;
 }
 await page.selectOption('#src','en');await page.selectOption('#dst','yue');await page.locator('summary').click();await page.locator('[data-sample="0"]').click();await page.locator('#translate').click();
 await page.locator('[data-action="favorite"]').click();
 await page.locator('[data-action="full"]').click();assert.equal(await page.locator('#full').evaluate(e=>e.open),true);await page.locator('#full button').click();checks++;
 await page.locator('[data-tab="history"]').click();await page.check('#favorites');assert.equal(await page.locator('.content .result').count(),1);await page.reload();await page.locator('[data-tab="history"]').click();await page.check('#favorites');assert.equal(await page.locator('.content .result').count(),1);checks++;
 await page.locator('[data-tab="translate"]').click();await page.fill('#input','This is not a built-in example.');await page.locator('#translate').click();assert.ok((await page.locator('.error').innerText()).includes('示例模式'));checks++;
 await page.locator('[data-tab="conversation"]').click();await page.locator('summary').click();await page.locator('[data-sample="1"]').click();await page.locator('#translate').click();await page.locator('#b').click();await page.locator('summary').click();await page.locator('[data-sample="2"]').click();await page.locator('#translate').click();assert.equal(await page.locator('.turn').count(),2);checks++;
 // Test real-mode UI protocol using an explicit test double, not a language-quality test.
 await page.route('**/translate',async route=>{
  let data=route.request().postDataJSON();assert.ok(['en','zh','yue'].includes(data.source));
  await route.fulfill({json:{translation:'<img src=x onerror=alert(1)> 測試',jyutping:null,engine:'TEST DOUBLE'}});
 });
 await page.locator('[data-tab="settings"]').click();await page.uncheck('#demo');await page.fill('#token','test-only');
 await page.locator('[data-tab="translate"]').click();await page.fill('#input','Protocol test');await page.locator('#translate').click();await page.waitForSelector('.content .result');assert.ok((await page.locator('.content .result').first().innerText()).includes('<img'));assert.equal(await page.locator('.content .result img').count(),0);checks++;
 await page.locator('[data-tab="settings"]').click();await page.check('#demo');await page.locator('[data-tab="translate"]').click();await page.locator('summary').click();await page.locator('[data-sample="0"]').click();await page.locator('#translate').click();
 await page.setViewportSize({width:390,height:1100});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);checks++;
 if(process.env.VOKAWA_QA_FONT){const fs=require('node:fs');const dir=process.env.VOKAWA_QA_FONT;let css=fs.readFileSync(path.join(dir,'400.css'),'utf8');css=css.replace(/url\(\.\/([^)]*)\)/g,(_,p)=>'url(data:font/woff2;base64,'+fs.readFileSync(path.join(dir,p)).toString('base64')+')');await page.addStyleTag({content:css+"body{font-family:'Noto Sans SC',sans-serif}"});await page.evaluate(()=>document.fonts.ready);}
 await page.locator('.phone').screenshot({path:process.env.VOKAWA_SCREENSHOT||'preview/preview.png'});
 assert.deepEqual(errors,[]);console.log(JSON.stringify({checks,pageErrors:errors,viewport:'390px',screenshot:true}));await browser.close();backend.kill();
})().catch(e=>{console.error(e);backend?.kill();process.exit(1)});
