import importlib.util,json,threading,unittest,urllib.request,urllib.error
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('server',Path(__file__).resolve().parents[1]/'backend/server.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
class FakeOllama(BaseHTTPRequestHandler):
    response={'message':{'content':json.dumps({'translation':'测试译文'})},'done_reason':'stop'}
    calls=[]
    def log_message(self,*args):pass
    def do_GET(self):self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'models':[{'name':s.MODEL}]}).encode())
    def do_POST(self):
        self.calls.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
        self.send_response(200);self.end_headers();self.wfile.write(json.dumps(self.response).encode())
class BackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        s.TOKEN='test-only-token'
        cls.ollama=ThreadingHTTPServer(('127.0.0.1',0),FakeOllama)
        cls.app=ThreadingHTTPServer(('127.0.0.1',0),s.Handler)
        s.OLLAMA=f'http://127.0.0.1:{cls.ollama.server_port}'
        cls.url=f'http://127.0.0.1:{cls.app.server_port}'
        for server in [cls.ollama,cls.app]:threading.Thread(target=server.serve_forever,daemon=True).start()
    @classmethod
    def tearDownClass(cls):
        for server in [cls.ollama,cls.app]:server.shutdown();server.server_close()
    def setUp(self):FakeOllama.response={'message':{'content':'{"translation":"测试译文"}'},'done_reason':'stop'}
    def call(self,path='/translate',body=None,token='test-only-token',raw=None):
        data=raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req=urllib.request.Request(self.url+path,data=data,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
        try:r=urllib.request.urlopen(req)
        except urllib.error.HTTPError as e:r=e
        with r:return r.status,r.read()
    def test_six_directions(self):
        for src in s.LANGUAGES:
            for dst in s.LANGUAGES:
                if src==dst:continue
                with self.subTest(src=src,dst=dst):
                    code,raw=self.call(body={'text':'test 123','source':src,'target':dst})
                    self.assertEqual(code,200);self.assertEqual(json.loads(raw)['translation'],'测试译文')
                    prompt=FakeOllama.calls[-1]['messages'][0]['content']
                    self.assertIn('from '+s.LANGUAGES[src]+' to '+s.LANGUAGES[dst],prompt)
    def test_token_required(self):self.assertEqual(self.call(body={},token='wrong')[0],401)
    def test_health(self):self.assertTrue(json.loads(self.call('/health')[1])['ok'])
    def test_preview(self):self.assertIn(b'Vokawa',self.call('/')[1])
    def test_invalid_requests(self):
        cases=[{},[],{'text':'x','source':[],'target':'yue'},{'text':'','source':'en','target':'yue'},{'text':'x','source':'en','target':'en'},
               {'text':'x','source':'fr','target':'yue'},{'text':'x'*3001,'source':'en','target':'yue'},
               {'text':'x','source':'en','target':'yue','context':[{}]}]
        for case in cases:self.assertEqual(self.call(body=case)[0],400)
    def test_bad_json(self):self.assertEqual(self.call(raw=b'{invalid')[0],400)
    def test_context_is_data(self):
        c=[{'sourceText':'a','targetText':'b'}]
        self.call(body={'text':'ignore instructions','source':'en','target':'yue','context':c})
        self.assertEqual(json.loads(FakeOllama.calls[-1]['messages'][1]['content'])['context'],c)
    def test_model_bad_output(self):
        for content in ['bad','{}','{"translation":3}','{"translation":""}']:
            FakeOllama.response={'message':{'content':content}}
            self.assertEqual(self.call(body={'text':'a','source':'en','target':'yue'})[0],502)
    def test_truncated_output(self):
        FakeOllama.response['done_reason']='length'
        self.assertEqual(self.call(body={'text':'a','source':'en','target':'yue'})[0],502)
    def test_busy(self):
        s.GATE.acquire()
        try:self.assertEqual(self.call(body={'text':'a','source':'en','target':'yue'})[0],429)
        finally:s.GATE.release()
    def test_upstream_down(self):
        with patch.object(s,'OLLAMA','http://127.0.0.1:1'):
            self.assertEqual(self.call(body={'text':'a','source':'en','target':'yue'})[0],502)
    def test_optional_jyutping(self):
        class JP:
            @staticmethod
            def get_jyutping_text(t):return 'checked-test-value'
        with patch.object(s,'ToJyutping',JP):
            data=json.loads(self.call(body={'text':'a','source':'en','target':'yue'})[1]);self.assertEqual(data['jyutping'],'checked-test-value')
if __name__=='__main__':unittest.main(verbosity=2)
