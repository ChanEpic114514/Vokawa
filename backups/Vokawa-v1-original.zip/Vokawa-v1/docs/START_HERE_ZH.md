# Vokawa 第一版创建与运行教程

## 0. 本次交付是什么

这是 iPhone 原生 App 的完整工程源码，不是已经签名的 IPA。无需自己逐个创建文件：解压后直接打开 `ios/Vokawa.xcodeproj`。

附带浏览器预览与本地翻译后端。浏览器预览与 SwiftUI 界面为两套实现，共用服务协议、示例内容和功能设计。网页能运行不代表 iOS 已编译或音频已达标。

本次制作环境没有 macOS/Xcode，未执行 iOS 编译、模拟器或真机运行。请按下面步骤进行首次构建。

## 1. 准备环境

- 一台能运行当前 Xcode 的 Mac；在 Mac App Store 安装 Xcode，并完成首次启动安装。
- iOS 17 或更高版本的 iPhone。也可先用 Xcode iPhone 模拟器。
- Python 3.10 或更高版本。
- 真实翻译需要 Ollama：https://ollama.com/download 。本版默认模型为 `qwen3:8b`，模型需另外下载，未随压缩包提供。电脑内存、速度和模型下载空间需自行确认。

只试界面不需要 Ollama，不需要付费 API。

## 2. 先看预览

双击 `preview/index.html`，保持“示例模式”开启。首页已经填入一条内置句子，点击“翻译”。可切换源语言和目标语言，再从“载入示例句子”选择对应原文；所有六个方向均有示例。

还可测试收藏、历史、搜索、复制、全屏显示、对话和设置。浏览器能否使用麦克风、剪贴板、声音取决于浏览器权限和运行环境。用文件方式打开时，真实翻译不可用；下面通过后端打开。

## 3. 启动真实翻译服务

先打开 Ollama 应用。在 Mac“终端”运行：

```bash
ollama pull qwen3:8b
```

下载完成后，进入解压目录（将路径替换成实际位置）：

```bash
cd ~/Downloads/Vokawa-v1
python3 backend/server.py
```

终端会显示服务地址、模型名称和一串 `Connection token`。保持这个终端开启。每次未指定令牌重启，都会生成新令牌。

浏览器访问 http://127.0.0.1:8765 ，进入“设置”，粘贴连接令牌，点“测试连接”。成功后关闭“示例模式”，即可输入任意文字进行真实翻译。首次模型加载可能较慢。

后端使用 Python 标准库，不安装额外 Python 包也能翻译。

### 可选：启用粤拼

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r backend/requirements.txt
python3 backend/server.py
```

若无法安装，可继续不带粤拼运行。自动粤拼与译文都需要审校，不代表准确性保证。

### 更换模型

电脑性能不足可尝试较小模型，翻译质量需要重新评估：

```bash
ollama pull qwen3:4b
VOKAWA_MODEL=qwen3:4b python3 backend/server.py
```

不使用 `:cloud` 模型，本方案不要求第三方在线付费账户。

## 4. 在 Xcode 创建并运行 App

1. 解压工程，双击 `ios/Vokawa.xcodeproj`。
2. Xcode 顶部选择 `Vokawa` Scheme。
3. 选择已安装的 iPhone 模拟器。如没有，在 Xcode 下载相应 iOS Simulator。
4. 按 `⌘R` 构建并运行。
5. App 默认开启“示例模式”，进入“载入示例句子”完成第一次翻译。
6. 电脑后端运行后，在 App“设置”填入 `http://127.0.0.1:8765` 和终端令牌，测试连接并关闭示例模式。

模拟器只是界面和连接测试，语音最终必须用真机。

工程已生成；若工程文件损坏或需要重新生成，在项目根目录运行：

```bash
python3 scripts/create_project.py
```

也可以在 Xcode 手动 New Project → iOS App，选择 SwiftUI / Swift，最低 iOS 17；删除模板 Swift 文件，导入 `ios/Vokawa` 的四个 Swift 文件，将附带 `Info.plist` 设为目标的 Info.plist File。不要同时保留两个 `@main` App 入口。直接打开附带工程更简单。

## 5. 安装到真实 iPhone

1. 用数据线连接 Mac 和 iPhone，信任电脑；按系统提示启用 Developer Mode。
2. Xcode Settings → Accounts 登录自己的 Apple Account。
3. 工程 Target → Signing & Capabilities，开启 Automatically manage signing，并选择自己的 Team。
4. 把 Bundle Identifier 改为自己的唯一标识，例如 `com.yourname.vokawa.dev`。
5. 顶部运行设备选择自己的 iPhone，按 `⌘R`。按设备提示完成开发者信任。

个人本地测试可以使用个人 Apple Account，签名期限及设备限制由 Apple 管理；不要把它理解为永久公开分发。TestFlight / App Store 发布另需按 Apple Developer Program 流程准备。

### 手机连接电脑

**手机里的 127.0.0.1 指手机自己，不是 Mac。**

在 Mac 系统设置 → 网络 → 当前 Wi-Fi 的详细信息中查看局域网 IP，例如 `192.168.1.20`。在可信私人 Wi-Fi 下启动：

```bash
python3 backend/server.py --host 0.0.0.0
```

手机 App 的后端地址填 `http://192.168.1.20:8765`（替换为自己的 IP），令牌使用这次启动时显示的值。允许 App 的“本地网络”权限和 Mac 上 Python 的入站连接。

学校/宿舍网络可能隔离设备，即使 Wi-Fi 名称相同也无法互访。此时用允许设备互通的个人网络，或先用 Mac 模拟器。开发 HTTP 服务只用于可信本地网络，不应直接暴露到公网。

## 6. 语音使用

- 首次点“语音输入”，允许麦克风和语音识别权限。
- 默认开启“仅本机识别”。某个语言不支持时会提示；如愿意让 Apple 在线处理录音，可在设置关闭该开关。
- 点击结束录音后检查识别文字，必要时修改，再点击翻译。单次录音最多 55 秒。
- 在“设置”查看三种语言实际可用的系统声音。缺少粤语声音时，到 iPhone 辅助功能的朗读/语音设置下载香港粤语声音；不同 iOS 版本菜单名称可能不同。
- 原文、译文都能播放，也能停止和调速。系统朗读不是已审核标准粤语。
- 本次没有包含 Forvo、付费语音 API、真人发音包或 VITS 权重。不能宣称已解决粤语声调和多音字准确性问题。

## 7. 上传 GitHub

本包可以直接作为仓库根目录，无需把 App 转成网站。建议开发初期创建 Private 仓库。

在 GitHub 网站新建名为 `Vokawa` 的空仓库，然后在本地项目根目录运行：

```bash
git init
git add .
git commit -m "Add Vokawa iOS development version"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/Vokawa.git
git push -u origin main
```

把 `YOUR_USERNAME` 换成自己的用户名，按 GitHub 的登录方式授权。不要把连接令牌或个人签名凭据写入代码。`.gitignore` 已排除本地环境、Xcode 用户设置和大模型文件。

GitHub Pages 只适合发布浏览器示例预览，不会运行此 Python 后端，也不会生成 iOS 安装包。如果将预览放到 Pages，应保持示例模式；公开 HTTPS 页面无法按本教程可靠访问自己的 HTTP 局域网后端。

## 8. 常见问题

| 情况 | 处理 |
|---|---|
| 只能翻译五组句子 | 仍处于示例模式；先连接后端，再关闭示例模式 |
| 连接令牌不正确 | 复制当前后端终端显示的令牌 |
| 模型未下载 | 运行 `ollama pull qwen3:8b`，确保后端模型名称一致 |
| 手机连不上电脑 | 使用电脑局域网 IP，检查权限、防火墙及网络隔离 |
| 模型正在处理另一请求 | 等待上次请求结束；取消界面请求不会保证立刻停止 Ollama 推理 |
| 超时 | 先用短句，等待模型预热，或尝试较小模型 |
| 没有粤语声音 | 下载系统粤语声音；App 不会自动退回普通话 |
| 识别普通话而非粤语 | 确认原文语言为粵語；Apple 识别准确性需真机验证 |
| 自动粤拼错误或语音读错 | 属于语言质量问题，不能当作 UI 故障处理；记录输入、译文及设备声音以修正 |
| Xcode 签名失败 | 选择自己的 Team 和唯一 Bundle Identifier |

## 9. 本版发布边界

这是一版用于开发验证的完整功能链路，不是可直接上架的正式产品。上线前还需真机编译验收、粤语质量测试、正式图标、隐私说明和分发配置。

`Info.plist` 为局域网开发开启了 HTTP 例外。正式发布前改为 HTTPS 并移除 `NSAllowsArbitraryLoads`，重新审查隐私和数据流程。

官方参考：
- Xcode 设备运行：https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices
- Ollama API：https://docs.ollama.com/api/chat
- ToJyutping：https://github.com/CanCLID/ToJyutping
- 系统声音：https://developer.apple.com/documentation/avfaudio/avspeechsynthesisvoice
