#!/usr/bin/env python3
"""Recreate the checked-in Xcode project; no XcodeGen dependency."""
from pathlib import Path
import plistlib
ROOT=Path(__file__).resolve().parents[1]/'ios'
APP=ROOT/'Vokawa'; PROJ=ROOT/'Vokawa.xcodeproj'
PROJ.mkdir(exist_ok=True)
def ident(n): return f'{n:024X}'
files=['VokawaApp.swift','Models.swift','SpeechService.swift','Views.swift']
objects=[]
def obj(n,body): objects.append(f'{ident(n)} = {{ {body} }};')
for i,f in enumerate(files):
    obj(100+i,f'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {f}; sourceTree = "<group>";')
    obj(200+i,f'isa = PBXBuildFile; fileRef = {ident(100+i)};')
obj(1,f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; }}; buildConfigurationList = {ident(20)}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en,Base,); mainGroup = {ident(2)}; productRefGroup = {ident(4)}; projectDirPath = ""; projectRoot = ""; targets = ({ident(5)},);')
obj(2,f'isa = PBXGroup; children = ({ident(3)},{ident(4)},); sourceTree = "<group>";')
obj(3,'isa = PBXGroup; path = Vokawa; sourceTree = "<group>"; children = ('+','.join(ident(100+i) for i in range(len(files)))+',);')
obj(4,f'isa = PBXGroup; name = Products; children = ({ident(6)},); sourceTree = "<group>";')
obj(5,f'isa = PBXNativeTarget; buildConfigurationList = {ident(21)}; buildPhases = ({ident(7)},{ident(8)},{ident(9)},); buildRules = (); dependencies = (); name = Vokawa; productName = Vokawa; productReference = {ident(6)}; productType = "com.apple.product-type.application";')
obj(6,'isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = Vokawa.app; sourceTree = BUILT_PRODUCTS_DIR;')
obj(7,'isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ('+','.join(ident(200+i) for i in range(len(files)))+',); runOnlyForDeploymentPostprocessing = 0;')
for n,t in [(8,'PBXFrameworksBuildPhase'),(9,'PBXResourcesBuildPhase')]: obj(n,f'isa = {t}; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
for n,configs in [(20,(30,31)),(21,(32,33))]: obj(n,f'isa = XCConfigurationList; buildConfigurations = ({ident(configs[0])},{ident(configs[1])},); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
for n,name in [(30,'Debug'),(31,'Release')]:
    obj(n,f'isa = XCBuildConfiguration; name = {name}; buildSettings = {{ SDKROOT = iphoneos; IPHONEOS_DEPLOYMENT_TARGET = 17.0; CLANG_ENABLE_MODULES = YES; SWIFT_VERSION = 5.0; }};')
for n,name in [(32,'Debug'),(33,'Release')]:
    optimize='"-Onone"' if name=='Debug' else '"-O"'
    obj(n,f'isa = XCBuildConfiguration; name = {name}; buildSettings = {{ PRODUCT_NAME = "$(TARGET_NAME)"; PRODUCT_BUNDLE_IDENTIFIER = app.vokawa.dev; INFOPLIST_FILE = Vokawa/Info.plist; GENERATE_INFOPLIST_FILE = NO; CODE_SIGN_STYLE = Automatic; TARGETED_DEVICE_FAMILY = "1,2"; SWIFT_VERSION = 5.0; SWIFT_OPTIMIZATION_LEVEL = {optimize}; SWIFT_STRICT_CONCURRENCY = minimal; MARKETING_VERSION = 0.1.0; CURRENT_PROJECT_VERSION = 1; ENABLE_PREVIEWS = YES; LD_RUNPATH_SEARCH_PATHS = "$(inherited) @executable_path/Frameworks"; }};')
(PROJ/'project.pbxproj').write_text('// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n'+'\n'.join(objects)+f'\n}}; rootObject = {ident(1)}; }}\n')
info={'CFBundleDevelopmentRegion':'en','CFBundleDisplayName':'Vokawa','CFBundleExecutable':'$(EXECUTABLE_NAME)',
'CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'$(PRODUCT_NAME)',
'CFBundlePackageType':'APPL','CFBundleShortVersionString':'$(MARKETING_VERSION)','CFBundleVersion':'$(CURRENT_PROJECT_VERSION)',
'LSRequiresIPhoneOS':True,'UILaunchScreen':{},'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],
'NSMicrophoneUsageDescription':'点击语音输入时录音，用于将你说的话转成文字。',
'NSSpeechRecognitionUsageDescription':'使用 Apple 语音识别；关闭仅本机识别后，录音可能发送到 Apple 处理。',
'NSLocalNetworkUsageDescription':'连接同一 Wi-Fi 下电脑上的 Vokawa 本地翻译服务。',
'NSAppTransportSecurity':{'NSAllowsLocalNetworking':True,'NSAllowsArbitraryLoads':True}}
(APP/'Info.plist').write_bytes(plistlib.dumps(info))
scheme=f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ident(5)}" BuildableName="Vokawa.app" BlueprintName="Vokawa" ReferencedContainer="container:Vokawa.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ident(5)}" BuildableName="Vokawa.app" BlueprintName="Vokawa" ReferencedContainer="container:Vokawa.xcodeproj"/></BuildableProductRunnable></LaunchAction><ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ident(5)}" BuildableName="Vokawa.app" BlueprintName="Vokawa" ReferencedContainer="container:Vokawa.xcodeproj"/></BuildableProductRunnable></ProfileAction><AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>'''
p=PROJ/'xcshareddata/xcschemes';p.mkdir(parents=True,exist_ok=True);(p/'Vokawa.xcscheme').write_text(scheme)
print('Created',PROJ)
