import AVFoundation
import Speech
import Security
import Foundation
import Combine

enum KeychainToken {
    private static let query: [String:Any] = [kSecClass as String:kSecClassGenericPassword,
        kSecAttrService as String:"Vokawa",kSecAttrAccount as String:"backend-token"]
    static func read() -> String {
        var q=query; q[kSecReturnData as String]=true; q[kSecMatchLimit as String]=kSecMatchLimitOne
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&item)==errSecSuccess, let data=item as? Data else { return "" }
        return String(data:data,encoding:.utf8) ?? ""
    }
    static func save(_ token: String) {
        SecItemDelete(query as CFDictionary)
        guard !token.isEmpty else { return }
        var q=query; q[kSecValueData as String]=Data(token.utf8)
        q[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(q as CFDictionary,nil)
    }
}

@MainActor final class SpeechService: ObservableObject {
    @Published var recording=false
    @Published var transcript=""
    @Published var error: String?
    private let engine=AVAudioEngine()
    private let speaker=AVSpeechSynthesizer()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var tapInstalled=false
    private var generation=UUID()
    private var limitTask: Task<Void,Never>?

    func start(_ language: Language, onDeviceOnly: Bool) async {
        stop(); error=nil; transcript=""
        let id=UUID(); generation=id
        let authorized = await withCheckedContinuation { (c: CheckedContinuation<Bool,Never>) in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning:$0 == .authorized) }
        }
        let microphone = await withCheckedContinuation { (c: CheckedContinuation<Bool,Never>) in
            AVAudioSession.sharedInstance().requestRecordPermission { c.resume(returning:$0) }
        }
        guard generation==id, !Task.isCancelled else { return }
        guard authorized && microphone else { error="请在 iPhone 设置中允许麦克风与语音识别权限。"; return }
        guard let recognizer=SFSpeechRecognizer(locale:Locale(identifier:language.locale)), recognizer.isAvailable else {
            error="当前设备或网络无法使用此语言的语音识别。可以继续文字输入。"; return
        }
        if onDeviceOnly && !recognizer.supportsOnDeviceRecognition {
            error="此语言当前不支持本机识别。可在设置关闭“仅本机识别”，允许 Apple 在线识别。"; return
        }
        do {
            let session=AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord,mode:.measurement,options:[.defaultToSpeaker,.allowBluetooth])
            try session.setActive(true)
            let req=SFSpeechAudioBufferRecognitionRequest(); req.shouldReportPartialResults=true
            req.requiresOnDeviceRecognition=onDeviceOnly; request=req
            let node=engine.inputNode; let format=node.outputFormat(forBus:0)
            guard format.sampleRate>0, format.channelCount>0 else { throw NSError(domain:"Vokawa",code:5,userInfo:[NSLocalizedDescriptionKey:"麦克风不可用"]) }
            node.installTap(onBus:0,bufferSize:1024,format:format) { buffer,_ in req.append(buffer) }
            tapInstalled=true
            task=recognizer.recognitionTask(with:req) { [weak self] result,failure in
                let text=result?.bestTranscription.formattedString
                let final=result?.isFinal ?? false
                let message=failure?.localizedDescription
                Task { @MainActor [weak self] in
                    guard let self, self.generation==id else { return }
                    if let text { self.transcript=text }
                    if final || message != nil {
                        self.stopRecording()
                        if let message, self.transcript.isEmpty { self.error=message }
                    }
                }
            }
            engine.prepare(); try engine.start(); recording=true
            limitTask=Task { [weak self] in
                try? await Task.sleep(for:.seconds(55))
                guard !Task.isCancelled else { return }
                self?.stopRecording()
            }
        } catch { stopRecording(); self.error=error.localizedDescription }
    }
    func stopRecording() {
        generation=UUID(); limitTask?.cancel(); limitTask=nil
        engine.stop()
        if tapInstalled { engine.inputNode.removeTap(onBus:0); tapInstalled=false }
        request?.endAudio(); task?.cancel(); task=nil; request=nil; recording=false
        try? AVAudioSession.sharedInstance().setActive(false,options:.notifyOthersOnDeactivation)
    }
    func stop() { stopRecording(); speaker.stopSpeaking(at:.immediate) }
    func speak(_ text: String, language: Language, rate: Double) {
        stop(); error=nil
        let voices=AVSpeechSynthesisVoice.speechVoices().filter {$0.language == language.locale}
        guard let voice=voices.sorted(by:{$0.quality.rawValue > $1.quality.rawValue}).first else {
            error="未找到 \(language.title) 系统声音。请在辅助功能的语音设置下载对应声音；不会改用普通话替代粤语。"; return
        }
        do {
            let session=AVAudioSession.sharedInstance()
            try session.setCategory(.playback,mode:.spokenAudio); try session.setActive(true)
            let utterance=AVSpeechUtterance(string:text); utterance.voice=voice
            utterance.rate=Float(rate); speaker.speak(utterance)
        } catch { self.error=error.localizedDescription }
    }
    func voiceDescription(_ language: Language) -> String {
        let voices=AVSpeechSynthesisVoice.speechVoices().filter {$0.language == language.locale}
        return voices.map(\.name).joined(separator:", ").isEmpty ? "未安装" : voices.map(\.name).joined(separator:", ")
    }
}
