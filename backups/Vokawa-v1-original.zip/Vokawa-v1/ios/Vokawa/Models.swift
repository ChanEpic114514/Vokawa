import Foundation
import SwiftUI

enum Language: String, Codable, CaseIterable, Identifiable {
    case english = "en", mandarin = "zh", cantonese = "yue"
    var id: String { rawValue }
    var title: String { switch self { case .english: return "English"; case .mandarin: return "普通话"; case .cantonese: return "粵語" } }
    var locale: String { switch self { case .english: return "en-US"; case .mandarin: return "zh-CN"; case .cantonese: return "zh-HK" } }
}
struct Entry: Codable, Identifiable {
    var id = UUID()
    var date = Date()
    var source: Language
    var target: Language
    var sourceText: String
    var targetText: String
    var jyutping: String?
    var engine: String
    var favorite = false
    var demo = false
}
struct TranslationResponse: Decodable {
    let translation: String
    let jyutping: String?
    let engine: String
    let notice: String?
}
struct ErrorResponse: Decodable { let error: String }
struct HealthResponse: Decodable { let ok: Bool; let message: String; let jyutping: Bool }
struct Phrase {
    let en: String; let zh: String; let yue: String; let jyutping: String
    func text(_ language: Language) -> String { switch language { case .english: return en; case .mandarin: return zh; case .cantonese: return yue } }
}
enum Samples {
    static let phrases = [
        Phrase(en:"How much is this?",zh:"这个多少钱？",yue:"呢個幾多錢？",jyutping:"ni1 go3 gei2 do1 cin2"),
        Phrase(en:"Where is the nearest station?",zh:"最近的车站在哪里？",yue:"最近嘅車站喺邊度？",jyutping:"zeoi3 gan6 ge3 ce1 zaam6 hai2 bin1 dou6"),
        Phrase(en:"Please speak more slowly.",zh:"请说慢一点。",yue:"唔該講慢啲。",jyutping:"m4 goi1 gong2 maan6 di1"),
        Phrase(en:"I would like a glass of water.",zh:"我想要一杯水。",yue:"我想要一杯水。",jyutping:"ngo5 soeng2 jiu3 jat1 bui1 seoi2"),
        Phrase(en:"Hello!",zh:"你好！",yue:"你好！",jyutping:"nei5 hou2")
    ]
}

@MainActor final class AppStore: ObservableObject {
    @Published var entries: [Entry] = []
    @Published var storageError: String?
    @Published var demoMode: Bool { didSet { defaults.set(demoMode,forKey:"demo") } }
    @Published var endpoint: String { didSet { defaults.set(endpoint,forKey:"endpoint") } }
    @Published var token: String { didSet { KeychainToken.save(token) } }
    @Published var autoPlay: Bool { didSet { defaults.set(autoPlay,forKey:"autoPlay") } }
    @Published var saveHistory: Bool { didSet { defaults.set(saveHistory,forKey:"saveHistory") } }
    @Published var showJyutping: Bool { didSet { defaults.set(showJyutping,forKey:"showJyutping") } }
    @Published var rate: Double { didSet { defaults.set(rate,forKey:"rate") } }
    @Published var onDeviceOnly: Bool { didSet { defaults.set(onDeviceOnly,forKey:"onDeviceOnly") } }
    @Published var source: Language { didSet { defaults.set(source.rawValue,forKey:"source") } }
    @Published var target: Language { didSet { defaults.set(target.rawValue,forKey:"target") } }
    private let defaults = UserDefaults.standard
    private var file: URL { URL.documentsDirectory.appending(path:"history.json") }
    init() {
        let d = UserDefaults.standard
        demoMode = d.object(forKey:"demo") as? Bool ?? true
        endpoint = d.string(forKey:"endpoint") ?? "http://127.0.0.1:8765"
        token = KeychainToken.read()
        autoPlay = d.bool(forKey:"autoPlay")
        saveHistory = d.object(forKey:"saveHistory") as? Bool ?? true
        showJyutping = d.object(forKey:"showJyutping") as? Bool ?? true
        rate = d.object(forKey:"rate") as? Double ?? 0.45
        onDeviceOnly = d.object(forKey:"onDeviceOnly") as? Bool ?? true
        source = Language(rawValue:d.string(forKey:"source") ?? "en") ?? .english
        target = Language(rawValue:d.string(forKey:"target") ?? "yue") ?? .cantonese
        if source == target { target = source == .cantonese ? .english : .cantonese }
        if FileManager.default.fileExists(atPath:file.path) {
            do { entries = try JSONDecoder().decode([Entry].self,from:Data(contentsOf:file)) }
            catch { storageError = "历史记录读取失败；原文件保留。新记录暂不写入，请先导出或检查 history.json。" }
        }
    }
    func persist() {
        guard storageError == nil else { return }
        do { try JSONEncoder().encode(entries).write(to:file,options:[.atomic, .completeFileProtection]) }
        catch { storageError = "无法保存记录：\(error.localizedDescription)" }
    }
    func add(_ entry: Entry) { if saveHistory { entries.insert(entry,at:0); trim(); persist() } }
    private func trim() {
        var count=0
        entries=entries.filter { entry in if entry.favorite { return true }; count += 1; return count <= 500 }
    }
    func toggleFavorite(_ entry: Entry) {
        if let i=entries.firstIndex(where:{$0.id==entry.id}) { entries[i].favorite.toggle() }
        else { var copy=entry; copy.favorite=true; entries.insert(copy,at:0) }
        trim(); persist()
    }
    func isFavorite(_ entry: Entry) -> Bool { entries.first(where:{$0.id==entry.id})?.favorite ?? false }
    func remove(_ id: UUID) { entries.removeAll {$0.id==id}; persist() }
    func clear() { entries=[]; storageError=nil; persist() }
    func request(path: String, body: Data? = nil) throws -> URLRequest {
        guard let base=URL(string:endpoint.trimmingCharacters(in:.whitespacesAndNewlines)),
              ["http","https"].contains(base.scheme ?? ""), base.host != nil,
              base.user == nil, base.password == nil, base.query == nil, base.fragment == nil else {
            throw NSError(domain:"Vokawa",code:1,userInfo:[NSLocalizedDescriptionKey:"请输入正确的服务地址"])
        }
        var r=URLRequest(url:base.appending(path:path)); r.timeoutInterval=130
        r.setValue("Bearer \(token)",forHTTPHeaderField:"Authorization")
        if let body { r.httpMethod="POST"; r.httpBody=body; r.setValue("application/json",forHTTPHeaderField:"Content-Type") }
        return r
    }
    func checkConnection() async throws -> String {
        let (data,response)=try await URLSession.shared.data(for:request(path:"health"))
        try validateHTTP(data,response)
        let health=try JSONDecoder().decode(HealthResponse.self,from:data)
        return health.message + (health.jyutping ? " · 粤拼已启用" : " · 粤拼未安装")
    }
    func translate(_ text: String, source: Language, target: Language, context: [Entry] = []) async throws -> Entry {
        let clean=text.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !clean.isEmpty, clean.count <= 3000, source != target else {
            throw NSError(domain:"Vokawa",code:2,userInfo:[NSLocalizedDescriptionKey:"请输入 1–3000 字符，并选择不同语言"])
        }
        if demoMode {
            guard let p=Samples.phrases.first(where:{$0.text(source).lowercased()==clean.lowercased()}) else {
                throw NSError(domain:"Vokawa",code:3,userInfo:[NSLocalizedDescriptionKey:"示例模式只支持内置句子。请选示例，或在设置连接本地翻译后端。"])
            }
            return Entry(source:source,target:target,sourceText:clean,targetText:p.text(target),jyutping:target == .cantonese ? p.jyutping:nil,engine:"内置示例",demo:true)
        }
        let body:[String:Any] = ["text":clean,"source":source.rawValue,"target":target.rawValue,
                                 "context":context.suffix(6).map {["sourceText":$0.sourceText,"targetText":$0.targetText]}]
        let (data,response)=try await URLSession.shared.data(for:request(path:"translate",body:JSONSerialization.data(withJSONObject:body)))
        try Task.checkCancellation(); try validateHTTP(data,response)
        let result=try JSONDecoder().decode(TranslationResponse.self,from:data)
        return Entry(source:source,target:target,sourceText:clean,targetText:result.translation,jyutping:result.jyutping,engine:result.engine)
    }
    private func validateHTTP(_ data: Data,_ response: URLResponse) throws {
        guard let http=response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let message=(try? JSONDecoder().decode(ErrorResponse.self,from:data).error) ?? "服务请求失败"
            throw NSError(domain:"Vokawa",code:4,userInfo:[NSLocalizedDescriptionKey:message])
        }
    }
}
