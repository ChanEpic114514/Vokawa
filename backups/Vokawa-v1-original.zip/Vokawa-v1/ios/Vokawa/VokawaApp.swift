import SwiftUI

@main struct VokawaApp: App {
    @StateObject private var store=AppStore()
    @StateObject private var speech=SpeechService()
    @Environment(\.scenePhase) private var scene
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).environmentObject(speech)
                .onChange(of:scene) { _,new in if new != .active { speech.stop() } }
        }
    }
}
struct RootView: View {
    @EnvironmentObject private var speech: SpeechService
    @EnvironmentObject private var store: AppStore
    @State private var selection=0
    var body: some View {
        TabView(selection:$selection) {
            TranslateView().tabItem { Label("翻译",systemImage:"character.bubble") }.tag(0)
            ConversationView().tabItem { Label("对话",systemImage:"person.2") }.tag(1)
            HistoryView().tabItem { Label("记录",systemImage:"clock") }.tag(2)
            SettingsView().tabItem { Label("设置",systemImage:"gearshape") }.tag(3)
        }
        .tint(.teal)
        .onChange(of:selection) { _,_ in speech.stop() }
        .alert("语音提示",isPresented:Binding(get:{speech.error != nil},set:{if !$0 {speech.error=nil}})) {
            Button("知道了") { speech.error=nil }
        } message: { Text(speech.error ?? "") }
        .safeAreaInset(edge:.top) {
            if let message=store.storageError { Text(message).font(.caption).foregroundStyle(.red).padding(8) }
        }
    }
}
