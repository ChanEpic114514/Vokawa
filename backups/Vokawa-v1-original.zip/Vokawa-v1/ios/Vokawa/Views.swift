import SwiftUI
import UIKit

struct LanguagePicker: View {
    let title: String
    @Binding var language: Language
    var body: some View {
        Picker(title,selection:$language) { ForEach(Language.allCases) { Text($0.title).tag($0) } }
            .pickerStyle(.menu).accessibilityLabel(title)
    }
}
struct ModeNotice: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        Label(store.demoMode ? "示例模式 · 仅内置句子" : "本地模型 · 自动翻译",systemImage:store.demoMode ? "play.rectangle" : "desktopcomputer")
            .font(.caption).foregroundStyle(.secondary)
    }
}
struct ResultCard: View {
    let entry: Entry
    @EnvironmentObject var store: AppStore
    @EnvironmentObject var speech: SpeechService
    @State private var fullScreen=false
    var body: some View {
        VStack(alignment:.leading,spacing:14) {
            Text(entry.target.title).font(.caption).foregroundStyle(.secondary)
            Text(entry.targetText).font(.title2).textSelection(.enabled)
            if store.showJyutping, let jyutping=entry.jyutping { Text(jyutping).font(.subheadline).foregroundStyle(.secondary).textSelection(.enabled) }
            HStack(spacing:22) {
                Button { speech.speak(entry.targetText,language:entry.target,rate:store.rate) } label: { Image(systemName:"speaker.wave.2") }.accessibilityLabel("播放译文")
                Button { speech.stop() } label: { Image(systemName:"stop.circle") }.accessibilityLabel("停止播放")
                Button { UIPasteboard.general.string=entry.targetText } label: { Image(systemName:"doc.on.doc") }.accessibilityLabel("复制译文")
                Button { store.toggleFavorite(entry) } label: { Image(systemName:store.isFavorite(entry) ? "star.fill" : "star") }.accessibilityLabel("收藏")
                Spacer()
                Button { fullScreen=true } label: { Image(systemName:"arrow.up.left.and.arrow.down.right") }.accessibilityLabel("放大译文")
            }.font(.title3).buttonStyle(.borderless)
            Text(entry.engine + (entry.demo ? " · 示例" : " · 未经人工审核")).font(.caption2).foregroundStyle(.secondary)
            if entry.target == .cantonese { Text("系统粤语朗读 · 发音尚未审核；粤拼不控制系统读音。") .font(.caption2).foregroundStyle(.secondary) }
        }.padding().background(.background,in:RoundedRectangle(cornerRadius:16))
        .fullScreenCover(isPresented:$fullScreen) {
            NavigationStack { ScrollView { Text(entry.targetText).font(.largeTitle).padding(28).textSelection(.enabled) }
                .toolbar { ToolbarItem(placement:.topBarTrailing) { Button("完成") { fullScreen=false } } }
            }
        }
    }
}
struct TranslateView: View {
    @EnvironmentObject var store: AppStore
    @EnvironmentObject var speech: SpeechService
    @State private var input=""
    @State private var output: Entry?
    @State private var busy=false
    @State private var message: String?
    @State private var work: Task<Void,Never>?
    @State private var requestID=UUID()
    @State private var visible=false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:18) {
                    ModeNotice()
                    HStack {
                        LanguagePicker(title:"原文语言",language:$store.source)
                        Spacer()
                        Button { let a=store.source; store.source=store.target; store.target=a; if let output { input=output.targetText }; invalidate() } label: { Image(systemName:"arrow.left.arrow.right") }.accessibilityLabel("交换语言")
                        Spacer()
                        LanguagePicker(title:"译文语言",language:$store.target)
                    }
                    VStack(alignment:.leading,spacing:12) {
                        Text("输入文字，或点击麦克风").font(.caption).foregroundStyle(.secondary)
                        TextEditor(text:$input).frame(minHeight:130).scrollContentBackground(.hidden).accessibilityLabel("待翻译文字")
                        HStack {
                            Button { if speech.recording { speech.stopRecording() } else { Task { await speech.start(store.source,onDeviceOnly:store.onDeviceOnly) } } } label: {
                                Label(speech.recording ? "结束录音" : "语音输入",systemImage:speech.recording ? "stop.fill" : "mic.fill")
                            }
                            Spacer()
                            Button("清空") { speech.stop(); input=""; invalidate() }
                        }.buttonStyle(.borderless)
                    }.padding().background(.background,in:RoundedRectangle(cornerRadius:16))
                    if busy { HStack { ProgressView(); Text("正在翻译…"); Spacer(); Button("取消") { invalidate() } } }
                    else { Button(action:translate) { Text("翻译").frame(maxWidth:.infinity).padding(8) }.buttonStyle(.borderedProminent).disabled(input.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || store.source==store.target) }
                    if store.source==store.target { Text("请选择不同的语言").font(.caption).foregroundStyle(.red) }
                    if let message { Text(message).font(.callout).foregroundStyle(.red) }
                    if let output { ResultCard(entry:output) }
                    Menu("载入示例句子") { ForEach(Samples.phrases.indices,id:\.self) { i in Button(Samples.phrases[i].text(store.source)) { input=Samples.phrases[i].text(store.source) } } }
                    if !input.isEmpty { Button("朗读原文") { speech.speak(input,language:store.source,rate:store.rate) } }
                }.padding()
            }.background(Color(uiColor:.systemGroupedBackground)).navigationTitle("Vokawa")
        }
        .onChange(of:speech.transcript) { _,text in if visible { input=text } }
        .onChange(of:input) { _,_ in invalidate() }
        .onChange(of:store.source) { _,_ in speech.stop(); invalidate() }
        .onChange(of:store.target) { _,_ in speech.stop(); invalidate() }
        .onAppear { visible=true }
        .onDisappear { visible=false; invalidate(); speech.stop() }
    }
    private func invalidate() { requestID=UUID(); work?.cancel(); work=nil; busy=false; output=nil; message=nil }
    private func translate() {
        speech.stopRecording(); message=nil; output=nil; busy=true
        let id=UUID(); requestID=id; let text=input; let src=store.source; let dst=store.target
        work=Task { @MainActor in
            do {
                let entry=try await store.translate(text,source:src,target:dst)
                guard !Task.isCancelled,requestID==id else { return }
                output=entry; store.add(entry); busy=false
                if store.autoPlay { speech.speak(entry.targetText,language:dst,rate:store.rate) }
            } catch {
                guard !Task.isCancelled,requestID==id else { return }; message=error.localizedDescription; busy=false
            }
        }
    }
}

struct ConversationView: View {
    @EnvironmentObject var store: AppStore
    @EnvironmentObject var speech: SpeechService
    @State private var turns: [Entry]=[]
    @State private var text=""
    @State private var reverse=false
    @State private var busy=false
    @State private var message: String?
    @State private var work: Task<Void,Never>?
    @State private var requestID=UUID()
    @State private var visible=false
    private var src: Language { reverse ? store.target:store.source }
    private var dst: Language { reverse ? store.source:store.target }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:16) {
                    ModeNotice()
                    Text("轮流说话 · 录音结束后可修改文字，再发送翻译").font(.caption).foregroundStyle(.secondary)
                    ForEach(turns) { entry in
                        Text(entry.source.title+" · "+entry.sourceText).font(.callout).foregroundStyle(.secondary)
                        ResultCard(entry:entry)
                    }
                    Picker("说话方",selection:$reverse) { Text(store.source.title).tag(false); Text(store.target.title).tag(true) }.pickerStyle(.segmented)
                    TextEditor(text:$text).frame(height:100).padding(8).background(.background,in:RoundedRectangle(cornerRadius:12)).accessibilityLabel("本轮对话")
                    HStack {
                        Button { if speech.recording { speech.stopRecording() } else { Task { await speech.start(src,onDeviceOnly:store.onDeviceOnly) } } } label: { Label(speech.recording ? "结束" : "说话",systemImage:speech.recording ? "stop.fill":"mic.fill") }
                        Spacer()
                        if busy { ProgressView(); Button("取消") { cancel() } }
                        else { Button("翻译给对方") { send() }.buttonStyle(.borderedProminent).disabled(text.isEmpty || src==dst) }
                    }
                    if let message { Text(message).foregroundStyle(.red).font(.caption) }
                    Menu("示例") { ForEach(Samples.phrases.indices,id:\.self) { i in Button(Samples.phrases[i].text(src)) { text=Samples.phrases[i].text(src) } } }
                }.padding()
            }.background(Color(uiColor:.systemGroupedBackground)).navigationTitle("面对面对话")
                .toolbar { Button("新对话") { cancel(); speech.stop(); turns=[]; text="" } }
        }
        .onChange(of:speech.transcript) { _,new in if visible { text=new } }
        .onChange(of:text) { _,_ in if busy { cancel() } }
        .onChange(of:reverse) { _,_ in cancel(); speech.stop(); text="" }
        .onChange(of:store.source) { _,_ in cancel(); turns=[] }
        .onChange(of:store.target) { _,_ in cancel(); turns=[] }
        .onAppear { visible=true }
        .onDisappear { visible=false; cancel(); speech.stop() }
    }
    private func cancel() { requestID=UUID(); work?.cancel(); busy=false; message=nil }
    private func send() {
        speech.stopRecording(); busy=true; message=nil
        let id=UUID(); requestID=id; let input=text; let a=src; let b=dst; let context=turns
        work=Task { @MainActor in
            do {
                let entry=try await store.translate(input,source:a,target:b,context:context)
                guard !Task.isCancelled, requestID==id else { return }
                busy=false; turns.append(entry); store.add(entry); text=""
                if store.autoPlay { speech.speak(entry.targetText,language:b,rate:store.rate) }
            } catch { guard !Task.isCancelled,requestID==id else { return }; busy=false; message=error.localizedDescription }
        }
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: AppStore
    @State private var query=""
    @State private var favoritesOnly=false
    var filtered: [Entry] { store.entries.filter { (!favoritesOnly || $0.favorite) && (query.isEmpty || ($0.sourceText+$0.targetText).localizedCaseInsensitiveContains(query)) } }
    var body: some View {
        NavigationStack {
            List {
                Toggle("只看收藏",isOn:$favoritesOnly)
                if filtered.isEmpty { ContentUnavailableView("还没有记录",systemImage:"clock",description:Text("翻译后会出现在这里，也可以关闭自动保存。")) }
                ForEach(filtered) { entry in
                    VStack(alignment:.leading,spacing:8) {
                        Text(entry.sourceText).font(.callout).foregroundStyle(.secondary)
                        ResultCard(entry:entry)
                    }.swipeActions { Button("删除",role:.destructive) { store.remove(entry.id) } }
                }
            }.navigationTitle("记录与收藏").searchable(text:$query,prompt:"搜索原文或译文")
        }
    }
}
struct SettingsView: View {
    @EnvironmentObject var store: AppStore
    @EnvironmentObject var speech: SpeechService
    @State private var health=""
    @State private var checking=false
    @State private var confirmClear=false
    var body: some View {
        NavigationStack {
            Form {
                Section("翻译服务") {
                    Toggle("示例模式",isOn:$store.demoMode)
                    Text("关闭后使用电脑上的 Ollama 模型；此版本无内置通用翻译模型。").font(.caption).foregroundStyle(.secondary)
                    TextField("http://电脑IP:8765",text:$store.endpoint).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    SecureField("后端连接令牌",text:$store.token).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button(checking ? "检查中…":"测试连接") { checking=true; Task { do { health=try await store.checkConnection() } catch { health=error.localizedDescription }; checking=false } }.disabled(checking)
                    if !health.isEmpty { Text(health).font(.caption) }
                }
                Section("语音") {
                    Toggle("仅本机识别",isOn:$store.onDeviceOnly)
                    Text("关闭后，Apple 可能在线处理录音。仅在点击录音时启用麦克风，单次最多 55 秒。").font(.caption).foregroundStyle(.secondary)
                    Toggle("翻译后自动播放",isOn:$store.autoPlay)
                    Slider(value:$store.rate,in:0.25...0.6) { Text("语速") }
                    Text("语速 \(store.rate,format:.number.precision(.fractionLength(2)))")
                    ForEach(Language.allCases) { language in LabeledContent(language.title,value:speech.voiceDescription(language)) }
                    Text("粤语声音未通过人工审核。没有粤语声音时提示下载，绝不替换成普通话。显示的粤拼不控制系统朗读。").font(.caption).foregroundStyle(.secondary)
                }
                Section("记录与显示") {
                    Toggle("显示粤拼",isOn:$store.showJyutping)
                    Toggle("保存翻译历史",isOn:$store.saveHistory)
                    Text("关闭后不保存新历史；手动收藏仍保存。已有记录不会自动删除。").font(.caption).foregroundStyle(.secondary)
                    Button("删除全部历史与收藏",role:.destructive) { confirmClear=true }
                }
                Section("版本") { Text("Vokawa 0.1 · 开发测试版"); Text("录音不保存。历史仅在本机；真实翻译会把当前文字与最多六轮对话发送到设置中的后端。").font(.caption) }
            }.navigationTitle("设置")
            .confirmationDialog("删除全部历史与收藏？",isPresented:$confirmClear,titleVisibility:.visible) { Button("全部删除",role:.destructive) { store.clear() } }
        }
    }
}
